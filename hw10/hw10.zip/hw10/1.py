import numpy as np
import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
#from IPython import get_ipython
#get_ipython().run_line_magic('matplotlib', 'inline')

data = input_data.read_data_sets("./mnist/", one_hot=True)
print("Training X: ", data.train.images.shape)
print("Training Y: ", data.train.labels.shape)
print("Test X: ", data.test.images.shape)
print("Test Y: ", data.test.labels.shape)
def gaussian_additive_noise(x, std):
    return x + tf.random_normal(shape=tf.shape(x), dtype=tf.float32, mean=0.0, stddev=std)
imgs = tf.placeholder(tf.float32, shape=[None, 28*28], name="Input")

noise = gaussian_additive_noise(imgs, 0.1)
corrupted_imgs_test = noise.eval(session=tf.Session(), feed_dict={imgs: data.test.images})

def plot_mnist(imgs, lbls):
    
    classes = np.argmax(lbls, 1)

    for i in range(10):
        ids = (classes == i)
        
        images = imgs[ids][0:10]
            
        for j in range(3):   
            plt.subplot(5, 10, i + j*10 + 1)
            plt.imshow(images[j].reshape(28, 28), cmap='gray')

            if j == 0:
                plt.title(i)
                
            plt.axis('off')
    plt.savefig("plot.png")
	
def autoencoder(dims=[28*28, 512, 256], std=0.01):
    
    x = tf.placeholder(tf.float32, shape=[None, dims[0]], name="Input")

    cur = gaussian_additive_noise(x, 0.1)
    
    Ws = []
    bs = []
    
    # encoder
    for i, n_out in enumerate(dims[1:]):
        n_inp = int(cur.get_shape()[1])
        
        W = tf.Variable(tf.random_normal(shape=[n_inp, n_out], mean=0.0, stddev=std, dtype=tf.float32))
        b = tf.Variable(tf.random_normal(shape=[n_out], mean=0.0, stddev=std, dtype=tf.float32))
        
        Ws.append(W)
        bs.append(b)
        
        out = tf.nn.tanh(tf.matmul(cur, W) + b)
        cur = out
        
    z = cur
    Ws.reverse()
    bs.reverse()
    
    # decoder
    for i, n_out in enumerate(dims[:-1][::-1]):
        
        W = tf.transpose(Ws[i])
        b = tf.Variable(tf.random_normal(shape=[n_out], mean=0.0, stddev=std, dtype=tf.float32))
        
        
        out = tf.nn.tanh(tf.matmul(cur, W) + b)
        cur = out
    
    y = cur
    
    loss = tf.reduce_mean(tf.square(y - x))
    
    return (x, z, y, loss)	
lr = 0.001
batch_size = 64
n_epochs = 50
n_batchs = data.train.num_examples // batch_size

x, z, y, loss = autoencoder(dims=[28*28, 512, 256, 64], std=0.01)
optimizer = tf.train.AdamOptimizer(lr).minimize(loss)


S = tf.Session()
S.run(tf.global_variables_initializer())


for i_epoch in range(1, n_epochs+1):
    loss_avg = 0.0
    for i_batch in range(1, n_batchs+1):
        b, _ = data.train.next_batch(batch_size)
        _, loss_val = S.run([optimizer, loss], feed_dict={x: b})
        loss_avg = (loss_val / batch_size)
    print(i_epoch, loss_avg)
    loss_avg = 0.0


n_samples = 10
reconstructed = S.run([y], feed_dict={x: corrupted_imgs_test})

reconstructed = reconstructed[0]

#print("\t\t Original Images")
#plot_mnist(data.test.images, data.test.labels)
#print("\t\t Corrupted Images")
#plot_mnist(corrupted_imgs_test, data.test.labels)
#print("\t\t Reconstructed Images")
#plot_mnist(reconstructed, data.test.labels)

residualError = data.test.images - reconstructed
#plt.subplot(5, 10, i + j*10 + 1)

#plt.savefig("mean_residual_error.png")
ipca = PCA(n_components=5)
ipca.fit(residualError)
min0 = ipca.components_[0].min()
max0 = ipca.components_[0].max()
min1 = ipca.components_[1].min()
max1 = ipca.components_[1].max()
min2 = ipca.components_[2].min()
max2 = ipca.components_[2].max()
min3 = ipca.components_[3].min()
max3 = ipca.components_[3].max()
min4 = ipca.components_[4].min()
max4 = ipca.components_[4].max()
min5 = residualError.min()
max5 = residualError.max()
minAll = min(min0, min1, min2, min3, min4, min5)
maxAll = max(max0, max1, max2,max3, max4, max5)
plt.subplot(2, 6, 1)
plt.imshow(((np.mean(residualError, axis=0)- minAll)*255/(maxAll-minAll)).reshape(28, 28), cmap='gray',  interpolation='none')
plt.title("Mean Error")
plt.subplot(2, 6, 2)
plt.imshow(((ipca.components_[0]- minAll) * 255.0/(maxAll-minAll)).reshape(28, 28), cmap='gray',  interpolation='none')
plt.title("PC 1")
plt.subplot(2, 6, 3)
plt.imshow(((ipca.components_[1]- minAll) * 255.0/(maxAll-minAll)).reshape(28, 28), cmap='gray',  interpolation='none')
plt.title("PC 2")
plt.subplot(2, 6, 4)
plt.imshow(((ipca.components_[2]- minAll) * 255.0/(maxAll-minAll)).reshape(28, 28), cmap='gray',  interpolation='none')
plt.title("PC 3")
plt.subplot(2, 6, 5)
plt.imshow(((ipca.components_[3]- minAll) * 255.0/(maxAll-minAll)).reshape(28, 28), cmap='gray',  interpolation='none')
plt.title("PC 4")
plt.subplot(2, 6, 6)
plt.imshow(((ipca.components_[4]- minAll) * 255.0/(maxAll-minAll)).reshape(28, 28), cmap='gray',  interpolation='none')
plt.title("PC 5")

plt.subplot(2, 6, 7)
plt.imshow(np.mean(residualError, axis=0).reshape(28, 28), cmap='gray',  interpolation='none')
plt.subplot(2, 6, 8)
plt.imshow(ipca.components_[0].reshape(28, 28), cmap='gray',  interpolation='none')
plt.subplot(2, 6, 9)
plt.imshow(ipca.components_[1].reshape(28, 28), cmap='gray',  interpolation='none')
plt.subplot(2, 6, 10)
plt.imshow(ipca.components_[2].reshape(28, 28), cmap='gray',  interpolation='none')
plt.subplot(2, 6, 11)
plt.imshow(ipca.components_[3].reshape(28, 28), cmap='gray',  interpolation='none')
plt.subplot(2, 6, 12)
plt.imshow(ipca.components_[4].reshape(28, 28), cmap='gray',  interpolation='none')
plt.savefig("output1.png")
