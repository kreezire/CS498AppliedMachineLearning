#PART #1

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from collections import Counter
import math
import random
from scipy.spatial.distance import euclidean

filename1 = "C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/docword.nips.txt"

filename2 = "C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/vocab.nips.txt"

with open(filename1) as f:
    data = f.read().split("\n")   # original data file
    
with open(filename2) as g:
    vocab = g.read().split("\n")  # vocabulary file

data1 = data[3:len(data)-1]       # remove the first three lines and last line
    
doc_word_count = np.zeros((1500, 12419))

for i in range(np.shape(data1)[0]):    
    # make the data matrix
    docID = int(data1[i].split()[0]) - 1 
    wordID = int(data1[i].split()[1]) - 1
    count = float(data1[i].split()[2])

    doc_word_count[docID, wordID] = count

topic = 30
W = np.zeros((doc_word_count.shape[0], topic))
topic_prob = np.zeros(topic)

word = doc_word_count.shape[1] #12419

document = doc_word_count.shape[0] #1500

class Cluster(object):
    def __init__(self, points):
        self.points = points
        self.n = points.shape[1]
        self.centroid = self.calculateCentroid()

    def __repr__(self):
        return str(self.points)

    def update(self, points):
        old_centroid = self.centroid
        self.points = points
        if len(self.points) == 0:
            return 0

        self.centroid = self.calculateCentroid()
        shift = euclidean(old_centroid, self.centroid)
        return shift

    def calculateCentroid(self):
        unzipped = zip(*self.points)
        centroid_coords = [math.fsum(dList)/len(self.points) for dList in unzipped]
        return np.array(centroid_coords)

def get_points_cluster_labels(points, k, cutoff):

    # Pick out  random points to use as our initial centroids
    initial_centroids = random.sample(points, k)

    clusters = [Cluster(np.array([p])) for p in initial_centroids]

    # Loop through the dataset until the clusters stabilize
    loopCounter = 0
    while True:
        # Create a list of lists to hold the points in each cluster
        lists = [[] for _ in clusters]
        loopCounter += 1

        point_labels = []
        for p in points:
            smallest_distance = euclidean(p, clusters[0].centroid)

            clusterIndex = 0

            # For the remainder of the clusters ...
            for i in range(1, k):
                distance = euclidean(p, clusters[i].centroid)
                # If it's closer to that cluster's centroid update what we
                if distance < smallest_distance:
                    smallest_distance = distance
                    clusterIndex = i
            lists[clusterIndex].append(p)
            point_labels.append(clusterIndex)

        biggest_shift = 0.0

        for i in range(k):
            shift = clusters[i].update(lists[i])
            biggest_shift = max(biggest_shift, shift)

        # If the centroids have stopped moving much, say we're done!
        if biggest_shift < cutoff:
            print "Converged after %s iterations" % loopCounter
            break
            
    return np.array(point_labels)

points_cluster_labels = get_points_cluster_labels(doc_word_count,topic,.01)

print points_cluster_labels


for i in range(topic):
    topic_prob[i] = (Counter(points_cluster_labels)[i]*1.)/ (doc_word_count.shape[0])

word_for_topic_prob_temp = np.zeros((topic_prob.shape[0],  doc_word_count.shape[1]))

word_for_topic_prob_temp = np.zeros((topic,  doc_word_count.shape[1]))
for i, label in enumerate(points_cluster_labels):
     for j in range(topic):
               if label == j:
                    word_for_topic_prob_temp[j, ] += doc_word_count[i,]
for i in range(topic):
     for j in range(doc_word_count.shape[1]):
            
            if word_for_topic_prob_temp[i,j] == 0:
                word_for_topic_prob_temp[i,j] += 1
                         
word_for_topic_prob = word_for_topic_prob_temp / np.sum(word_for_topic_prob_temp, axis = 1)[:, None]

W1_nom = np.zeros((document, topic))
temp1 = np.zeros((document, topic))
Z = np.zeros((document, doc_word_count.shape[1]))


for k in range(20):
    for i in range(document):
        for j in range(topic):
            temp1[i, j] = np.sum(doc_word_count[i,] * np.log(word_for_topic_prob[j,])) + np.log(topic_prob[j])
   
        Max = temp1.max(1)
        temp2 = np.exp(temp1 - Max[::,None])
        W = temp2 / temp2.sum(1)[::,None]
           
    word_for_topic_prob_nom = np.zeros((topic, doc_word_count.shape[1]))
    for i in range(topic):
         for j in range(document):
            word_for_topic_prob_nom[i, ] += np.dot(doc_word_count[j,], W[j,i])
    word_for_topic_prob_nom += 0.00001    # prevent 0 word probability
    word_for_topic_prob_denom = np.sum(word_for_topic_prob_nom, axis = 1) + 0.00001*doc_word_count.shape[1] 
    word_for_topic_prob = word_for_topic_prob_nom / word_for_topic_prob_denom[::, np.newaxis]

    topic_prob = np.sum(W, axis = 1) / document


#######Get the probability with the topic is selected
topic_index = np.zeros(document)
prob = np.zeros(30)
for i in range(document):    
        topic_index[i] = np.argsort(W[i,])[::-1][0]
        for j in range(topic):
            if topic_index[i] == j:
                  prob[j] +=  1
prob = prob / document
ax, fig =  plt.subplots()  
plt.plot([i for i in range(1,31)], prob)
plt.xlabel('Topic')
plt.ylabel('Probability') 
plt.title("Topic Probability Chart")
plt.show()    


Vocab = vocab[0:len(vocab) - 1]
freq_word_index = []
freq_word = np.zeros((topic, 10))

# select top 10 words for each topic
for i in range(topic):
    freq_word_index.append(np.argsort(word_for_topic_prob[i,])[::-1][:10])

freq_word = np.zeros((topic,10), dtype = object)

for i in range(len(freq_word_index)): #30
    for j in range(10):
             freq_word[i][j]= vocab[freq_word_index[i][j]]

df = pd.DataFrame(freq_word)
df.to_csv("freq_word.csv")

df.head(30)


#PART #2

from PIL import Image
from copy import deepcopy
import numpy as np
import math
import random
from scipy.spatial.distance import euclidean
from collections import Counter
from sklearn.cluster import KMeans

import matplotlib.pyplot as plt

import warnings 
warnings.filterwarnings('ignore')

def getPixel(pic):  #One method to construct pixel data from pictures

    r = np.zeros((pic.size[0], pic.size[1]))
    g = np.zeros((pic.size[0], pic.size[1]))
    b = np.zeros((pic.size[0], pic.size[1]))
    
    for i in range(pic.size[0]):
        for j in range(pic.size[1]):
            r[i,j] = pic.getpixel((i,j))[0]
            g[i,j] = pic.getpixel((i,j))[1]
            b[i,j] = pic.getpixel((i,j))[2]
            
        Pixel_data = np.transpose(np.array((r.ravel(), g.ravel(), b.ravel())))
        Pixel_data_scaled = (Pixel_data - np.mean(Pixel_data, axis = 0)) / np.std(Pixel_data, axis = 0)
    return Pixel_data, Pixel_data_scaled  # scale the data

class Cluster(object):
    def __init__(self, points):
        self.points = points
        self.n = points.shape[1]
        self.centroid = self.calculateCentroid()

    def __repr__(self):
        return str(self.points)

    def update(self, points):
        old_centroid = self.centroid
        self.points = points
        if len(self.points) == 0:
            return 0

        self.centroid = self.calculateCentroid()
        shift = euclidean(old_centroid, self.centroid)
        return shift

    def calculateCentroid(self):
        unzipped = zip(*self.points)
        centroid_coords = [math.fsum(dList)/len(self.points) for dList in unzipped]
        return np.array(centroid_coords)

def get_points_cluster_labels_and_centroids(points, k, cutoff=0.1):
     
    # Pick out  random points to use as our initial centroids
    initial_centroids =random.sample(points, k)
    clusters = [Cluster(np.array([p])) for p in initial_centroids]

    # Loop through the dataset until the clusters stabilize
    loopCounter = 0
    while True:
        # Create a list of lists to hold the points in each cluster
        lists = [[] for _ in clusters]
        loopCounter += 1

        point_labels = []
        for p in points:
            smallest_distance = euclidean(p, clusters[0].centroid)

            clusterIndex = 0

            # For the remainder of the clusters ...
            for i in range(1, k):
                distance = euclidean(p, clusters[i].centroid)
                # If it's closer to that cluster's centroid update what we
                if distance < smallest_distance:
                    smallest_distance = distance
                    clusterIndex = i
            lists[clusterIndex].append(p)
            point_labels.append(clusterIndex)

        biggest_shift = 0.0

        for i in range(k):
            shift = clusters[i].update(lists[i])
            biggest_shift = max(biggest_shift, shift)

        # If the centroids have stopped moving much, say we're done!
        if biggest_shift < cutoff:
            print "Converged after %s iterations" % loopCounter
            break
            
    return np.array(point_labels) , np.array([i.centroid for i in clusters])


def generate_Image(pic_path, segment, seed = 0):
    pic = Image.open(pic_path)
     
    width = pic.size[0]
    height = pic.size[1]

    Pixel = getPixel(pic)[1]

    segment_prob = np.zeros(segment)
    
    print 'clustering ' , segment
    img_clustered_labels , img_cluster_centroids = get_points_cluster_labels_and_centroids(Pixel,segment,seed)
    print 'clustering done'
    for i in range(segment):
        segment_prob[i] = Counter(img_clustered_labels)[i]*1. / Pixel.shape[0] 

    W2_nom = np.zeros((Pixel.shape[0], segment)) 
    prev_loss = 0

    for k in range(0, 10):
        for i in range(Pixel.shape[0]):
             for j in range(segment):
                W2_nom[i,j] = np.exp(-0.5*(np.dot((Pixel[i,] - img_cluster_centroids[j,]), \
                        (Pixel[i,] - img_cluster_centroids[j,])))) * segment_prob[j]

        W2_denom = np.sum(W2_nom, axis = 1)  

        W2 = W2_nom / W2_denom[::, None]

        img_cluster_centroids_denom = np.sum(W2, axis = 0)
        img_cluster_centroids_nom = np.zeros((segment, 3))

        for m in range(segment):
            for n in range(Pixel.shape[0]):
                img_cluster_centroids_nom[m,] += Pixel[n,] * W2[n,m]

        img_cluster_centroids = img_cluster_centroids_nom / img_cluster_centroids_denom[::, None]       

        segment_prob = np.sum(W2, axis = 0) / Pixel.shape[0]  #update pi

        current_loss = 0
        for i in range(Pixel.shape[0]):
            for j in range(segment):
                current_loss += (-0.5*(np.dot((Pixel[i,] - img_cluster_centroids[j,:]),(Pixel[i,] - img_cluster_centroids[j,:]))) + \
                     np.log(segment_prob[j])) * W2[i,j]

        if np.abs(current_loss - prev_loss) < 0.0001:
            print 'convereged'
            break
        else:
            prev_loss = current_loss

    ###  Map each pixel to the cluster center
    ###with the highest value of the posterior probability for that pixel

    segment_index = []
    for i in range(Pixel.shape[0]):   # Get the cluster
        segment_index.append(np.argsort(W2[i,])[segment - 1])

    Pixel_new = deepcopy(Pixel)

    for i in range(Pixel.shape[0]):
        Pixel_new[i,] = img_cluster_centroids[segment_index[i],]

    Pixel_back = np.zeros((width, height, 3))  

    for k in range(Pixel.shape[0]): # transform the data back to original dimension
        i = k // height
        j = k % height
        Pixel_back[i,j,] = Pixel_new[k,]

    Pixel_final_mirror = deepcopy(Pixel_back) 

    for i in range(width):     #mirror the image
        for j in range(height):
              Pixel_final_mirror[i, j,] = Pixel_back[i, height - 1 - j,]

    Pixel_final_rotate = np.zeros((height, width, 3))
    for i in range(width):    #rotate the image     
        for j in range(height):
            Pixel_final_rotate[j, i, ] = Pixel_final_mirror[i, height -1 - j, ]   

    Pixel_scaled_back =  (Pixel_final_rotate * getPixel(pic)[0].std(0)) + getPixel(pic)[0].mean(0)

    img = Image.fromarray(Pixel_scaled_back.astype(np.uint8), "RGB")
    img.show()
    if height == 330:
        img.save("C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/smallsunset" + str(seed) + "_" + str(segment) + "segments.jpg")
    elif height == 399:
        img.save("C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/smallstrelitzia" + "_" + str(segment) + "segments.jpg")
    else:
        img.save("C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/RobertMixed03" + "_" + str(segment) + "segments.jpg")
    return img


pic1 = "C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/smallsunset.jpg"
pic2 = "C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/smallstrelitzia.jpg"
pic3 = "C:/Users/dhane/Desktop/MS Assignments/CS489/HW-7/RobertMixed03.jpg"

#smallsunset.jpg
generate_Image(pic1, segment = 10)  
 
#smallsunset.jpg (five different start points)
random.seed(34)
generate_Image(pic1, segment = 20)
random.seed(54)
generate_Image(pic1, segment = 20)
random.seed(65)
generate_Image(pic1, segment = 20)
random.seed(105)
generate_Image(pic1, segment = 20)
random.seed(144)
generate_Image(pic1, segment = 20)

generate_Image(pic1, segment = 50)

#smallstrelitzia.jpg
generate_Image(pic2, segment = 10)  
generate_Image(pic2, segment = 20)
generate_Image(pic2, segment = 50)

#RobertMixed03.jpg
generate_Image(pic3, segment = 10)  
generate_Image(pic3, segment = 20)
generate_Image(pic3, segment = 50)
