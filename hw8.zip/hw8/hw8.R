eqhq<- function(value){
  2*value -1
}
energry<-function(Q, image, rows, cols){
  tiny_value<-1e-10
  sum1 <- sum(Q*log(Q + tiny_value) + (1-Q)*log(1 - Q + tiny_value))
  #print(sum1)
  sum2<-0
  num.rows<-28
  num.cols<-28
  for(i in 1:rows)
  { 
    for(j in  1:cols)
    {
     
      if(i>1 & i< num.rows & j>1 & j<num.cols)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i, j-1]) + eqhq(Q[i-1, j]) + eqhq(Q[i, j+1]) + eqhq(Q[i+1, j]))
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j-1] + image[i-1,j] + image[i,j+1] + image[i+1,j])
        
        }
      else if(i==1 & j==1)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*( eqhq(Q[i, j+1]) + eqhq(Q[i+1, j]))
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*( image[i,j+1] + image[i+1,j])
      }
      else if(i==1 & j==num.cols)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i, j-1])  + eqhq(Q[i+1, j]))
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j-1]  + image[i+1,j])
      }
      else if(i==num.rows & j==1)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*( eqhq(Q[i-1, j]) + eqhq(Q[i, j+1]) )
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*( image[i-1,j] + image[i,j+1] )
      }
      else if(i==num.rows & j==num.cols)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i, j-1]) + eqhq(Q[i-1, j]) )
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j-1] + image[i-1,j] )
      }
      else if(i==1)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i, j-1])  + eqhq(Q[i, j+1]) + eqhq(Q[i+1, j]))
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j-1]  + image[i,j+1] + image[i+1,j])
      }
      else if(j==1)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i-1, j]) + eqhq(Q[i, j+1]) + eqhq(Q[i+1, j]))
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*( image[i-1,j] + image[i,j+1] + image[i+1,j])
      }
      else if(i==num.rows)
      {
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i, j-1]) + eqhq(Q[i-1, j]) + eqhq(Q[i, j+1]) )
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j-1] + image[i-1,j] + image[i,j+1] )
      }
      else
      {
        #print(i)
        #print(j)
        sum2<- sum2 + 0.8 *eqhq(Q[i, j])*(eqhq(Q[i, j-1]) + eqhq(Q[i-1, j]) + eqhq(Q[i+1, j]))
        #sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j-1] + image[i-1,j] +  image[i+1,j])
        
      }
      sum2<- sum2 + 2 *eqhq(Q[i, j])*(image[i,j] )
    }
  }
  sum1 -  sum2
}

roc<- function()
{
  c_vals<- c(5, 0.6, 0.4, 0.35, 0.3, 0.1)
  ##### reading data
  file.train_images<- file("train-images.idx3-ubyte", 'rb' )
  readBin(file.train_images,'integer',n=1,size=4,endian='big')
  
  num.image_in_dataset = readBin(file.train_images,'integer',n=1,size=4,endian='big')
  num.rows<-readBin(file.train_images,'integer',n=1,size=4,endian='big')
  num.cols = readBin(file.train_images,'integer',n=1,size=4,endian='big')
  
  num.images=20
  num.noise_bits=15
  x = readBin(file.train_images,'integer',n=20*num.rows*num.cols,size=1,signed=F)
  close(file.train_images)
  images_data = matrix(x, ncol=num.rows*num.cols, byrow=T)
  images_data[images_data<0.5*255]<- -1
  images_data[images_data>=0.5*255]<- 1
  #print(images_data[2,])
  
  
  
  Q_initial<-  read.csv("SupplementaryAndSampleData/InitialParametersModel.csv", sep = ",", header = FALSE)
  #Q_initial <- t(as.matrix(Q_initial))
  updateOrder<-  read.csv("SupplementaryAndSampleData/UpdateOrderCoordinates.csv", sep = ",", header = TRUE)
  num.update_order_count<- ncol(updateOrder)
  updateOrder <- updateOrder[, 2:num.update_order_count] +1
  num.update_order_count <- num.update_order_count-1
  ### make list of images
  list_images <- list()
  den_images <- list()
  orig_images<-list()
  
  for(iter_image in 1:num.images)
  {
    list_images[[iter_image]]<- matrix(images_data[iter_image, ],ncol= num.cols, byrow = T  )
    orig_images[[iter_image]]<-matrix(images_data[iter_image, ],ncol= num.cols, byrow = T  )
    #den_images[[iter_image]]<- matrix(images_data[iter_image, ],ncol= num.cols, byrow = T  )
    #list_images[[iter_image]]<-list_images[[iter_image]][,28:1]
  }
  ####### adding noise
  noise_data = read.csv("SupplementaryAndSampleData/NoiseCoordinates.csv", sep = ",", header = TRUE)
  noise_data<-as.matrix(noise_data[, 2:16 ])+1
  #tempImage<-list_images[[3]]
  ##tempImage[tempImage<0]<-0
  #image(t(tempImage)[, 28:1])
  #write.csv(tempImage, "temp.csv", row.names = F)
  for (iter_image in 1:num.images)
  {
    
    r<-(iter_image*2)-1
    c<-(iter_image*2)
    for(iter_noise in 1: ncol(noise_data))
    {
      # print(iter_noise)
      #  print("adding noise")
      #  print(noise_data[r, iter_noise] )
      
      # print(list_images[[iter_image]][noise_data[r, iter_noise] , noise_data[c, iter_noise]])
      list_images[[iter_image]][noise_data[r, iter_noise] , noise_data[c, iter_noise]] <- -1*list_images[[iter_image]][noise_data[r, iter_noise] , noise_data[c, iter_noise]]
      #print(list_images[[iter_image]][noise_data[iter_image*2-1, iter_noise] , noise_data[iter_image*2, iter_noise]])
    }
    #images_data[noise_data[iter_image*2-1, iter_image*2]]<- -1*images_data[noise_data[iter_image*2-1, iter_image*2]]
  }
  #tempImage<-list_images[[1]]
  #tempImage[tempImage<0]<-0
  #image(t(tempImage)[, 28:1])
  ####de-noise
  Q<-list()
  tiny_value<- 1e-10
  energy_matrix <- matrix(0, nrow = num.images,  ncol = 11)
  trp_fpr<-matrix(0, nrow =length(c_vals), ncol = 2 )
  print(length(c_vals))
  for(iter_big in 1:length(c_vals)){
    tp<-0
    fp<-0
    tn<-0
    fn<-0
    for(iter_image in 11:num.images)
    {  print("new image")
      den_images[[iter_image]]<-list_images[[iter_image]]
      Q[[iter_image]] <- Q_initial
      #if(iter_big==1)
      #  energy_matrix[iter_image, 1] <- energry(Q[[iter_image]], list_images[[iter_image]], 28, 28)
      #print(energy_matrix[iter_image, 1])
      for(iter_loop in 1:10)
      { print("new iter")
        for(iter_order in 1:num.update_order_count)
        {
          i<- updateOrder[iter_image *2 -1, iter_order]
          j<- updateOrder[iter_image *2 , iter_order]
          q_p<-0
          q_n<-0
          if(i>1 & i< num.rows & j>1 & j<num.cols)
          {
            #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
            #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
            q_p <- c_vals[iter_big]*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
            
          }
          else if(i==1 & j==1)
          {
            q_p <- c_vals[iter_big]*(2*Q[[iter_image]][i, j+1]-1 + 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j+1]-1 +  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1]  +  list_images[[iter_image]][i+1,j])
            #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] +  list_images[[iter_image]][i+1,j])
            
          }
          else if(i==1 & j==num.cols)
          {
            q_p <- c_vals[iter_big]*(  2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*( 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*(  2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*( list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i+1,j])
            #q_n <- -0.8*( 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(  list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i+1,j])
            
          }
          else if(i==num.rows & j==1)
          {
            q_p <- c_vals[iter_big]*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j+1] +  list_images[[iter_image]][i-1,j] )
            #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j+1] +   list_images[[iter_image]][i-1,j] )
            
          }
          else if(i==num.rows & j==num.cols)
          {
            q_p <- c_vals[iter_big]*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*( list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j])
            #q_n <- -0.8*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j])
            
          }
          else if(i==1)
          {
            q_p <- c_vals[iter_big]*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i+1,j])
            #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +   list_images[[iter_image]][i+1,j])
            
          }
          else if(j==1)
          {
            q_p <- c_vals[iter_big]*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1] +  list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
            #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] +   list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
            
          }
          else if(i==num.rows)
          {
            q_p <- c_vals[iter_big]*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j] )
            #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j] )
            
          }
          else
          {
            #print(i)
            #print(j)
            q_p <- c_vals[iter_big]*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
            q_n <- -c_vals[iter_big]*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
            #q_p <- 0.8*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
            #q_n <- -0.8*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*( list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
            
          }
          Q[[iter_image]][i,j] <- (exp(q_p) / (exp(q_n) + exp(q_p)))
          
          
        }
       # if(iter_big==1 & iter_loop <3)
      #    energy_matrix[iter_image, iter_loop+1] <- energry(Q[[iter_image]], list_images[[iter_image]], 28, 28)
      }
      for(iter_order in 1:num.update_order_count)
      {
        i<- updateOrder[iter_image *2 -1, iter_order]
        j<- updateOrder[iter_image *2 , iter_order]
        if( Q[[iter_image]][i,j]<0.5)
        {
          if(orig_images[[iter_image]][i,j] == -1 && list_images[[iter_image]][i,j] == 1)
            tp<-tp+1
          else if(orig_images[[iter_image]][i,j] == -1 && list_images[[iter_image]][i,j] == -1)
            tn<-tn+1
          else if(orig_images[[iter_image]][i,j] == 1 &&  list_images[[iter_image]][i,j] == 1)
            fp<-fp+1
          else if(orig_images[[iter_image]][i,j] == 1 &&  list_images[[iter_image]][i,j] == -1)
            fn<-fn+1
          #den_images[[iter_image]][i,j]<- 0
        }
        else
        {
          if(orig_images[[iter_image]][i,j] == -1 && list_images[[iter_image]][i,j] == 1)
            fn<-fn+1
          else if(orig_images[[iter_image]][i,j] == -1 && list_images[[iter_image]][i,j] == -1)
            fp<-fp+1
          else if(orig_images[[iter_image]][i,j] == 1 &&  list_images[[iter_image]][i,j] == 1)
            tn<-tn+1
          else if(orig_images[[iter_image]][i,j] == 1 &&  list_images[[iter_image]][i,j] == -1)
            tp<-tp+1
        }
      }
      
     # print(energy_matrix[iter_image, 1:2])
      #list_images[[iter_image]] <- den_images[[iter_image]]
    }
    print(tp)
    print(fp)
    print(tn)
    print(fn)
    trp_fpr[iter_big, 1]<-tp/(tp+fn)
    trp_fpr[iter_big, 2]<- fp/(fp+tn)
    #print(tpr)
    #print(fpr)
  }
  write.table(trp_fpr , "trp_fpr.csv", sep = ',', row.names = FALSE, col.names = FALSE)
  
}
hw8<- function()
{
  roc()
  ##### reading data
  file.train_images<- file("train-images.idx3-ubyte", 'rb' )
  readBin(file.train_images,'integer',n=1,size=4,endian='big')

  num.image_in_dataset = readBin(file.train_images,'integer',n=1,size=4,endian='big')
  num.rows<-readBin(file.train_images,'integer',n=1,size=4,endian='big')
  num.cols = readBin(file.train_images,'integer',n=1,size=4,endian='big')
  
  num.images=20
  num.noise_bits=15
  x = readBin(file.train_images,'integer',n=20*num.rows*num.cols,size=1,signed=F)
  close(file.train_images)
  images_data = matrix(x, ncol=num.rows*num.cols, byrow=T)
  images_data[images_data<0.5*255]<- -1
  images_data[images_data>=0.5*255]<- 1
  #print(images_data[2,])
  
  
  
  Q_initial<-  read.csv("SupplementaryAndSampleData/InitialParametersModel.csv", sep = ",", header = FALSE)
  #Q_initial <- t(as.matrix(Q_initial))
  updateOrder<-  read.csv("SupplementaryAndSampleData/UpdateOrderCoordinates.csv", sep = ",", header = TRUE)
  num.update_order_count<- ncol(updateOrder)
  updateOrder <- updateOrder[, 2:num.update_order_count] +1
  num.update_order_count <- num.update_order_count-1
  ### make list of images
  list_images <- list()
  den_images <- list()
  for(iter_image in 1:num.images)
  {
    list_images[[iter_image]]<- matrix(images_data[iter_image, ],ncol= num.cols, byrow = T  )
    #den_images[[iter_image]]<- matrix(images_data[iter_image, ],ncol= num.cols, byrow = T  )
    #list_images[[iter_image]]<-list_images[[iter_image]][,28:1]
  }
  ####### adding noise
  noise_data = read.csv("SupplementaryAndSampleData/NoiseCoordinates.csv", sep = ",", header = TRUE)
  noise_data<-as.matrix(noise_data[, 2:16 ])+1
  #tempImage<-list_images[[3]]
  #tempImage[tempImage<0]<-0
  #image(t(tempImage)[, 28:1])
  #write.csv(tempImage, "temp.csv", row.names = F)
  for (iter_image in 1:num.images)
  {
   r<-(iter_image*2)-1
   c<-(iter_image*2)
    for(iter_noise in 1: ncol(noise_data))
    {
     # print(iter_noise)
    #  print("adding noise")
    #  print(noise_data[r, iter_noise] )
      
     # print(list_images[[iter_image]][noise_data[r, iter_noise] , noise_data[c, iter_noise]])
      list_images[[iter_image]][noise_data[r, iter_noise] , noise_data[c, iter_noise]] <- -1*list_images[[iter_image]][noise_data[r, iter_noise] , noise_data[c, iter_noise]]
      #print(list_images[[iter_image]][noise_data[iter_image*2-1, iter_noise] , noise_data[iter_image*2, iter_noise]])
    }
    #images_data[noise_data[iter_image*2-1, iter_image*2]]<- -1*images_data[noise_data[iter_image*2-1, iter_image*2]]
  }
  #tempImage<-list_images[[1]]
  #tempImage[tempImage<0]<-0
  #image(t(tempImage)[, 28:1])
  ####de-noise
  Q<-list()
  tiny_value<- 1e-10
  energy_matrix <- matrix(0, nrow = num.images,  ncol = 11)
  for(iter_big in 1:1){
  for(iter_image in 1:num.images)
  {  print("new image")
    den_images[[iter_image]]<-list_images[[iter_image]]
    Q[[iter_image]] <- Q_initial
    if(iter_big==1)
    energy_matrix[iter_image, 1] <- energry(Q[[iter_image]], list_images[[iter_image]], 28, 28)
    print(energy_matrix[iter_image, 1])
    for(iter_loop in 1:10)
    { print("new iter")
      for(iter_order in 1:num.update_order_count)
      {
        i<- updateOrder[iter_image *2 -1, iter_order]
        j<- updateOrder[iter_image *2 , iter_order]
        q_p<-0
        q_n<-0
        if(i>1 & i< num.rows & j>1 & j<num.cols)
        {
          #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
          #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
          q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
          
        }
        else if(i==1 & j==1)
        {
          q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1]  +  list_images[[iter_image]][i+1,j])
          #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] +  list_images[[iter_image]][i+1,j])
          
        }
        else if(i==1 & j==num.cols)
        {
          q_p <- 0.8*(  2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*( 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*(  2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*( list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i+1,j])
          #q_n <- -0.8*( 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(  list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i+1,j])
          
        }
        else if(i==num.rows & j==1)
        {
          q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j+1] +  list_images[[iter_image]][i-1,j] )
          #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j+1] +   list_images[[iter_image]][i-1,j] )
          
        }
        else if(i==num.rows & j==num.cols)
        {
          q_p <- 0.8*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*( list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j])
          #q_n <- -0.8*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j])
          
        }
        else if(i==1)
        {
          q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i+1,j])
          #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+  2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +   list_images[[iter_image]][i+1,j])
          
        }
        else if(j==1)
        {
          q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 +  (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j+1] +  list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
          #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 +  (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j+1] +   list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
          
        }
        else if(i==num.rows)
        {
          q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*(2*Q[[iter_image]][i, j+1]-1 + 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)) + 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j] )
          #q_n <- -0.8*(2*Q[[iter_image]][i,j+1]-1 + 2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)) - 2*(list_images[[iter_image]][i,j+1] + list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j] )
          
        }
        else
        {
          #print(i)
          #print(j)
          q_p <- 0.8*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j])
          q_n <- -0.8*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*(list_images[[iter_image]][i,j])
          #q_p <- 0.8*( 2*Q[[iter_image]][i, j-1]-1+ (2*Q[[iter_image]][i-1, j] -1)+ 2* Q[[iter_image]][i+1, j]-1) + 2*(list_images[[iter_image]][i,j-1] + list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
          #q_n <- -0.8*(2*Q[[iter_image]][i,j-1]-1+ (2*Q[[iter_image]][i-1,j] -1)+ 2* Q[[iter_image]][i+1,j]-1) - 2*( list_images[[iter_image]][i,j-1] +  list_images[[iter_image]][i-1,j] + list_images[[iter_image]][i+1,j])
          
        }
        Q[[iter_image]][i,j] <- (exp(q_p) / (exp(q_n) + exp(q_p)))
        
        
      }
      if(iter_big==1 & iter_loop <3)
      energy_matrix[iter_image, iter_loop+1] <- energry(Q[[iter_image]], list_images[[iter_image]], 28, 28)
    }
    for(iter_order in 1:num.update_order_count)
    {
      i<- updateOrder[iter_image *2 -1, iter_order]
      j<- updateOrder[iter_image *2 , iter_order]
      if( Q[[iter_image]][i,j]<0.5)
      {
        den_images[[iter_image]][i,j]<- 0
      }
      else
      {
        den_images[[iter_image]][i,j]<- 1
      }
    }
    print(energy_matrix[iter_image, 1:2])
    list_images[[iter_image]] <- den_images[[iter_image]]
  }
  }
  print(energy_matrix[11:12, 1:2])
  image_write_Data <- den_images[[11]]
  for (iter in 12:20)
  {
    image_write_Data <- cbind(image_write_Data , den_images[[iter]])
  }
  image(t(image_write_Data)[, 28:1])
  write.table(image_write_Data , "denoised.csv", sep = ',', row.names = FALSE, col.names = FALSE)
  write.table(energy_matrix[11:12, 1:2] , "energy.csv", sep = ',', row.names = FALSE, col.names = FALSE)
}