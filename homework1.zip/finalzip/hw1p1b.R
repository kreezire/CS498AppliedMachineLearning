hw1p1b <- function(){
	##load data
  data <- read.csv("pima-indians-diabetes.data", header=FALSE);
  
  ###set NA to respective columns
  data[ data[,3]==0,3]<-NA
  data[ data[,4]==0,4]<-NA
  data[ data[,6]==0,6]<-NA
  data[ data[,8]==0,8]<-NA
  
  ####split the date
  set.seed(13)
  train_ind <- sample(seq_len(nrow(data)), size = floor(0.8 * nrow(data)))
  train_data <- data[train_ind,]
  test_data <- data[-train_ind,]

  #### separate features and labels
  test_features <- test_data[,-9]
  test_label <- test_data[,9]
  train_features <- train_data[,-9]
  train_label <- train_data[9]
  
  #### find features respective to class labels
  pos_train_id <- train_label >0
  pos_train_features <- train_features[pos_train_id,]
  neg_train_features <- train_features[!pos_train_id,]

  ##### normal distribution parameter computation
  pos_mean <- sapply(pos_train_features, mean, na.rm = T)
  neg_mean <- sapply(neg_train_features, mean, na.rm = T)
  pos_sd <- sapply(pos_train_features, sd, na.rm = T)
  neg_sd <- sapply(neg_train_features, sd, na.rm = T)
  ### normalize data
  pos_data_norm <- t((t(test_features) -pos_mean)/pos_sd)
  neg_data_norm <- t((t(test_features) -neg_mean)/neg_sd)
  ####compute scores
  pos_logs <- -(1/2)*rowSums(apply(pos_data_norm,c(1, 2)
                                   , function(x)x^2), na.rm=TRUE)-sum(log(pos_sd))
  neg_logs <- -(1/2)*rowSums(apply(neg_data_norm,c(1, 2)
                                   , function(x)x^2), na.rm=TRUE)-sum(log(neg_sd))
  #### find accuracy
  pos_prediction_flags <- pos_logs > neg_logs
  correct_predictions <- pos_prediction_flags == test_label
  accuracy <- sum(correct_predictions)/length(test_label)
  print (accuracy)
}