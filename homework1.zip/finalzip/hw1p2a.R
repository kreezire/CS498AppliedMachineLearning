### function to rescale images
rescale20<- function(x){
  m <- as.cimg( matrix(data.matrix(x), ncol = 28, nrow = 28, byrow = TRUE))
  resize(autocrop(m), 20, 20)
  #resize(as.double(crop.bbox(m, m>0)),20L,20L)
  matrix(resize(autocrop(m), 20, 20),  ncol=20*20, nrow=1, byrow = TRUE)
}

hw1p2a <- function(){
  library(naivebayes)
  #library(klaR)
  #library(caret)
  library(imager)
  library(quanteda)
  trainSize<-60000
  testSize<-10000
  ###load database
  fileTrainingImages = file("train-images.idx3-ubyte", "rb")
  fileTrainingLabels = file("train-labels.idx1-ubyte", "rb")
  fileTestLabels = file("t10k-labels.idx1-ubyte", "rb")
  fileTestImages = file("t10k-images.idx3-ubyte", "rb")
  readBin(fileTrainingImages, integer(),size=4, n=4,  endian = "big")
  readBin(fileTrainingLabels, integer(), size=4,n=2,  endian = "big")
  readBin(fileTestImages, integer(), n=4,size=4,  endian = "big")
  readBin(fileTestLabels, integer(), n=2,size=4,  endian = "big")
	###load labels
  trainLabels<-as.numeric(readBin(fileTrainingLabels,integer(), size=1, n=trainSize, endian="big", signed = FALSE))
  testLabels<-as.numeric(readBin(fileTestLabels,integer(), size=1, n=testSize, endian="big", signed = FALSE))
  ### load train features
  xTrain = as.numeric(readBin(fileTrainingImages, 'integer', n = trainSize * 28 * 28, size = 1, signed = FALSE))
  ### threshold
  trainImage<-data.frame(matrix(xTrain, ncol = 28 * 28, byrow = TRUE))
  trainImage[trainImage<120]<-0
  trainImage[trainImage>=120]<-255
  trainImage<-trainImage[,784:1]
  ### load test features
  xTest = as.numeric(readBin(fileTestImages, 'integer', n = testSize * 28 * 28, size = 1, signed = FALSE))
  #### threshold
  testImages<-data.frame(matrix(xTest, ncol = 28 * 28, byrow = TRUE))
  testImages[testImages<120]<-0
  testImages[testImages>=120]<-255
  testImages<-testImages[,784:1]

  #### close files
  close(fileTrainingLabels)
  close(fileTrainingImages)
  close(fileTestImages)
  close(fileTestLabels)

  ### Naive Gaussian
   model<- naive_bayes(trainImage, trainLabels, na.action = na.pass())
   prediction<-predict(model,newdata=testImages)
   print("Naive Gaussian")
   print(sum(prediction==testLabels)/length(prediction))

   ### Naive Bernoulli
   model<-textmodel_nb(as.dfm(trainImage), as.factor(trainLabels), distribution = "Bernoulli", 
                smooth = 1)
  prediction<-predict(model,as.dfm(testImages))

  print("naive bernoulli")
  print(sum(as.data.frame(prediction$nb.predicted) ==testLabels)/length(testLabels))

	##### do image rescaling
  trainImage20<-t(apply(trainImage, 1, function(x) rescale20(x)))
  testImage20<-t(apply(testImages, 1, function(x) rescale20(x)))

  ### naive gaussian on rescaled data
  model<- naive_bayes(trainImage20, trainLabels, na.action=na.pass())
  prediction<-predict(model,newdata=testImage20)
  #confusionMatrix(prediction, testLabels)
  print("naive gaussian scaled")
  print(sum(prediction==testLabels)/length(testLabels))
 
  ### naive bernoulli on rescaled data
   model<-textmodel_nb(as.dfm(trainImage20), as.factor(trainLabels), distribution = "Bernoulli", 
                      smooth = 1)
  prediction<-predict(model,as.dfm(testImage20))
  print("naive bernoulli scaled")
  print(sum(as.data.frame(prediction$nb.predicted) ==testLabels)/length(testLabels))
  

  
}

