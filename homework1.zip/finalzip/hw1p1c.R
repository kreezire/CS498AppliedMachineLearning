hw1p1c<-function(){
	###load libraries
  library(klaR)
  library(caret)
  ##Load data
  data <- read.csv("pima-indians-diabetes.data", header=FALSE);
  labels<-as.factor(data[,9])
  features<-data[,-9]
  ### split data
  train_indices <- createDataPartition(y = labels, p = 0.8, list = FALSE)
  train_features <- features[train_indices,]
  train_labels <- labels[train_indices]
  test_features <- features[-train_indices,]
  test_labels <- labels[-train_indices]
  ## train
  model<-train(train_features, train_labels, 'nb', trControl=trainControl(method='cv', number=10), na.action=na.omit)
  ## predict
  prediction<-predict(model,newdata=test_features)
  confusionMatrix(data=prediction, test_labels)
}