rescale20<- function(x){
  m <- as.cimg( matrix(data.matrix(x), ncol = 28, nrow = 28, byrow = TRUE))
  resize(autocrop(m), 20, 20)
  #resize(as.double(crop.bbox(m, m>0)),20L,20L)
  matrix(resize(autocrop(m), 20, 20),  ncol=20*20, nrow=1, byrow = TRUE)
}
dopredict<-function(data, test, tree, depth){
  model<-h2o.randomForest(1:ncol(data)-1,  ncol(data),as.h2o(data), ntree = tree, max_depth = depth )
  prediction<-h2o.predict(
    object = model
    ,newdata = as.h2o(test))
  print(sum(prediction$predict==as.h2o(test)[ncol(test)])/nrow(test))
}

doSomePrediction<-function(x, y, testx, testy){
  data<-x
  data[,ncol(data)+1]<-y
  test<-testx
  test[,ncol(test)+1]<-testy
  #print(as.h2o(test))
  print("depth 4, tree 10")
  dopredict(data,  test, 10, 4)
  print("depth 8, tree 10")
  dopredict(data,  test, 10, 8)
  print("depth 16, tree 10")
  dopredict(data,  test, 10, 16)
  
  print("depth 4, tree 20")
  dopredict(data,  test, 20, 4)
  print("depth 8, tree 20")
  dopredict(data,  test, 20, 8)
  print("depth 16, tree 20")
  dopredict(data,  test, 20, 16)
  
  print("depth 4, tree 30")
  dopredict(data,  test, 30, 4)
  print("depth 8, tree 30")
  dopredict(data,  test, 30, 8)
  print("depth 16, tree 30")
  dopredict(data,  test, 30, 16)
  
  
}

hw1p2b<-function(){
  library(h2o)
  library(imager)
  h2o.init(
    nthreads=-1,            ## -1: use all available threads
    max_mem_size = "2G") 
  trainSize<-60000
  testSize<-10000
  fileTrainingImages = file("train-images-idx3-ubyte/train-images.idx3-ubyte", "rb")
  fileTrainingLabels = file("train-labels-idx1-ubyte/train-labels.idx1-ubyte", "rb")
  fileTestLabels = file("t10k-labels-idx1-ubyte/t10k-labels.idx1-ubyte", "rb")
  fileTestImages = file("t10k-images-idx3-ubyte/t10k-images.idx3-ubyte", "rb")
  readBin(fileTrainingImages, integer(),size=4, n=4,  endian = "big")
  readBin(fileTrainingLabels, integer(), size=4,n=2,  endian = "big")
  readBin(fileTestImages, integer(), n=4,size=4,  endian = "big")
  readBin(fileTestLabels, integer(), n=2,size=4,  endian = "big")
  trainLabels<-as.factor(readBin(fileTrainingLabels,integer(), size=1, n=trainSize, endian="big", signed = FALSE))
  #testImages = data.frame(matrix(vector(), nrow = 0, ncol = 28*28))
  testLabels<-as.factor(readBin(fileTestLabels,integer(), size=1, n=testSize, endian="big", signed = FALSE))
  xTrain = (readBin(fileTrainingImages, 'integer', n = trainSize * 28 * 28, size = 1, signed = FALSE))
  trainImage<-data.frame(matrix(xTrain, ncol = 28 * 28, byrow = TRUE))
  trainImage[trainImage<120]<-0
  trainImage[trainImage>=120]<-255
  trainImage<-trainImage[,784:1]
  xTest = (readBin(fileTestImages, 'integer', n = testSize * 28 * 28, size = 1, signed = FALSE))
  testImages<-data.frame(matrix(xTest, ncol = 28 * 28, byrow = TRUE))
  testImages[testImages<120]<-0
  testImages[testImages>=120]<-255
  testImages<-testImages[,784:1]
  close(fileTrainingLabels)
  close(fileTrainingImages)
  close(fileTestImages)
  close(fileTestLabels)
  print("untouched")
  doSomePrediction(trainImage, trainLabels, testImages, testLabels)
  trainImage20<-t(apply(trainImage, 1, function(x) rescale20(x)))
  testImage20<-t(apply(testImages, 1, function(x) rescale20(x)))
  print("scaled")
  doSomePrediction(as.data.frame( trainImage20), trainLabels, as.data.frame(testImage20), testLabels)
  h2o.shutdown(prompt=FALSE)
  
}