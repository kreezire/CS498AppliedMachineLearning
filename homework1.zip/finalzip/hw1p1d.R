hw1p1d<-function(){
  library(caret)
  data <- read.csv("pima-indians-diabetes.data", header=FALSE);
  labels<-as.factor(data[,9])
  features<-data[,-9]
  ### split data
  train_indices <- createDataPartition(y = labels, p = 0.8, list = FALSE)
  train_features <- features[train_indices,]
  train_labels <- labels[train_indices]
  test_features <- features[-train_indices,]
  test_labels <- labels[-train_indices]
  
  ### train
  model<-svmlight(train_features, train_labels, pathsvm="C:/Users/vipaggar/Documents/coursera/ml/svmlight/")
  prediction <-predict(model, test_features)
  accuracy<-sum(prediction$class==test_labels)/length(test_labels)
  print(accuracy)
}