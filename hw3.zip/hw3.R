## refences: https://stackoverflow.com/questions/32113942/importing-cifar-10-data-set-to-r

library(grid)
drawImage<-function(r,g,b)
{
  
  img_matrix = rgb(r,g,b,maxColorValue=255)
  dim(img_matrix) = c(32,32)
  img_matrix = t(img_matrix) 
  grid.raster(img_matrix, interpolate=FALSE)
}

hw3<-function()
{
  labels <- read.table("cifar-10-batches-bin/batches.meta.txt")
  #images.rgb <- list()
  numLabels<-10
  num.files=6
  num.images = 10000 # Set to 10000 to retrieve all images per file to memory
  imageLabels<-vector(length = num.files*num.images)
  matImages <- matrix(nrow = num.files*num.images, ncol = 3*1024)
  eigenVectors <- list()
  # Cycle through all 5 binary files
  ###################read data###############################
  for (f in 1:5) {
    to.read <- file(paste("cifar-10-batches-bin/data_batch_", f, ".bin", sep=""), "rb")
    for(i in 1:num.images) {
      l <- readBin(to.read, integer(), size=1, n=1, endian="big")
      m <- as.integer(readBin(to.read, raw(), size=1, n=3*1024, endian="big"))
      #g <- as.integer(readBin(to.read, raw(), size=1, n=1024, endian="big"))
      #b <- as.integer(readBin(to.read, raw(), size=1, n=1024, endian="big"))
      #print(m)
      index <- num.images * (f-1) + i
      matImages[index,] = as.matrix(m, ncol=3072)#data.frame(r, g, b)
      imageLabels[index] = l+1
      
    }
    close(to.read)
    #print(labels[[1]][images.lab[[112]]])
    #drawImage(matImages[112,1:1024], matImages[112,1025:2048], matImages[112,2049:3072])
    remove(l,f,i,index, to.read)
  }
 
  ########################read data from test DB ################################
  to.read <- file("cifar-10-batches-bin/test_batch.bin", "rb")
  for(i in 1:num.images) {
    l <- readBin(to.read, integer(), size=1, n=1, endian="big")
    m <- as.integer(readBin(to.read, raw(), size=1, n=3*1024, endian="big"))
    #g <- as.integer(readBin(to.read, raw(), size=1, n=1024, endian="big"))
    #b <- as.integer(readBin(to.read, raw(), size=1, n=1024, endian="big"))
    #print(m)
    index <- num.images * (num.files-1) + i
    matImages[index,] = as.matrix(m, ncol=3072)#data.frame(r, g, b)
    imageLabels[index] = l+1
    
  }
  close(to.read)
  #########################compute mean################################
  meanImages = matrix(nrow =numLabels, ncol = 3*1024)
  errors<- vector(length = numLabels)
  for(i in 1:numLabels)
  {
    labelMask<-imageLabels==i
  #print(labelMask)
    #print(sum(labelMask))
    meanImages[i,]<-colSums(matImages[labelMask,])/sum(labelMask)
    ############### center around mean ############################
    matImages[labelMask,] = matImages[labelMask,] - meanImages[i,]
    pca<-prcomp(matImages[labelMask,], center = FALSE, scale. = FALSE)
    print("___________")
    eigenV<-pca$sd^2
    errors[i]<-sum(eigenV[21:3072])
    print(errors[i])
    eigenVectors[[i]]<-pca$rotation
    #print(dim(pca$rotation))
    #drawImage(meanImages[i,1:1024], meanImages[i,1025:2048], meanImages[i,2049:3072])
    
  }
  #print(eigenVectors)
  barplot(errors ,names.arg = labels[[1]] ,xlab = "Error",ylab = "Categories",col = "blue", main = "Errors",border = "red")
  print("part 2")
  distances<-dist(meanImages , method = "euclidean", upper = TRUE, diag = TRUE)
  print(distances)
  fit <- cmdscale(distances, eig = TRUE, k = 2)
  x <- fit$points[, 1]
  y <- fit$points[, 2]
  plot(x, y, pch = 19, xlim = range(x) + c(0, 600))
  text(x, y, pos = 4, labels = labels[[1]])
  print("part 3")
  errors<- matrix(nrow = numLabels, ncol = numLabels)
  for(i in 1:numLabels)
  {
    output<-tcrossprod(meanImages[, 1:20],eigenVectors[[i]][,1:20])
    
    for (j in 1:numLabels)
    {
      labelMask<-imageLabels==j
      errors[j,i]<-sum((matImages[labelMask,] - output[j,])^2)/sum(labelMask)
      
    }
    remove(output)
  }
  errors <- (errors + t(errors))/2
  print(errors)
  fit <- cmdscale(errors, eig = TRUE, k = 2)
  x <- fit$points[, 1]
  y <- fit$points[, 2]
  plot(x, y, pch = 19, xlim = range(x) + c(0, 600))
  text(x, y, pos = 4, labels = labels[[1]])
  
}