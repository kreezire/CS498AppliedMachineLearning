cost<- function(x, y, u, lambda)
{
  a <- u[1:(length(u)-1)]
  b <- u[length(u)]
  g0 <- lambda*(t(a)%*% a)/2
  as.numeric((1.0/(nrow(x)))*(sum(pmax(rep(0, length(y)), 1- y*(as.matrix(x)%*%a  + b )))) + g0)
}

predict<- function(x, u)
{
  a <- u[1:(length(u)-1)]
  b <- u[length(u)]
  prediction<- as.matrix(x)%*%a  + b 
  prediction[prediction>=0]<-1
  prediction[prediction<0]<- -1
  prediction
  
}

stepCost<-function(x, y, u, lambda)
{
  #a <-as.vector( matrix( u[1:(nrow(u)-1), ], ncol=1))
  a <- u[1:(length(u)-1)]
  b <- u[length(u)]
  value <- rep(0, length(u))
  #print(y)
  #print(x)
  for (i in 1:length(y))
  {
    if(y[i]*(t(a)%*%as.vector(as.matrix(x[i, ]))+b) >= 1)
    {
      value <- value +  c(lambda*a, 0)
    }
    else
    {
      #print(lambda*a-y[i]*x[i,])
      #print(-y[i])
      #print(lambda*a)
      #print(as.vector(x[i,]))
      
      value <- value +  c(as.numeric(lambda*a-y[i]*as.vector(x[i,])), (-y[i]))
    }
  }
  value<-value/length(y)
  value
}

hw2 <-function(){
  #library(plotly)
  ### read data
  data <- read.csv("adult.data", header=FALSE, stringsAsFactors = FALSE);
  data2 <- read.csv("adult.test", header=FALSE,  skip = 1, stringsAsFactors = FALSE);
  data <- rbind(data[, c(1,3,5,11,12,13, 15)], data2[, c(1,3,5,11,12,13, 15)])
  
  #### remove rows with NA
  na.omit(data)
  
  x<- as.data.frame(data[,1:6])
  ytemp<-data[,7]
  ytemp <- ytemp == " >50K"
  y<-as.matrix(rep(-1, length(ytemp)),  ncol = 1)
  y[ytemp] <- 1
  
  #### scale variables for 1 variance
  x<-apply(x, 2, function(x) scale(x))
  
  ###split data
  set.seed(123)
  train_ind <- sample(seq_len(nrow(x)), size = (0.8 * nrow(x)))
  xtrain <- x[train_ind,]
  ytrain <- y[train_ind]
  xremain <- x[-train_ind,]
  yremain <- y[-train_ind]
  validationIndices <- sample(seq_len(nrow(xremain)), size = floor(0.5 * nrow(xremain)))
  xValidation <- xremain[validationIndices,]
  yValidation <- yremain[validationIndices]
  xTest <- xremain[-validationIndices,]
  yTest <- yremain[-validationIndices]
  
  ###  constants
  lambdas <- c(1e-3, 1e-2, 1e-1, 1)
  accuracies<- vector(mode = "numeric", length = length(lambdas))
 
  epochLength <- 300
  numEpoch <-  50
  m <- 1
  n <- 10
  evalStep <- 30
  batchSize <- 50
  ###graph stuff
 
  accPloty1 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  accPloty2 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  accPloty3 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  accPloty4 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  magnitudePloty1 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  magnitudePloty2 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  magnitudePloty3 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  magnitudePloty4 <- matrix( ncol = 1, nrow = epochLength*numEpoch/30)
  index<-0
  u1 <- vector(length = ncol(xtrain)+1)
  u2 <- vector(length = ncol(xtrain)+1)
  u3 <- vector(length = ncol(xtrain)+1)
  u4 <- vector(length = ncol(xtrain)+1)
  
  for (lambda in lambdas)
  {
    index<-index+1
    u <- rep(1, ncol(xtrain)+1)
   
    graphIndex<-1
    for (season in 1:numEpoch)
    {
      print("new season")
      stepSize <- m/ (season + n)
      heldOutIndex <- sample(seq_len(nrow(xtrain)), 50)
      xTrainRemain<-xtrain[-heldOutIndex,]
      #print(xTrainRemain)
      xHeldOut<-xtrain[heldOutIndex,]
      yTainRemain <- ytrain[-heldOutIndex]
      yHeldOut <- ytrain[heldOutIndex]
      for (step in 1:epochLength)
      {
        batchIndex <- sample(seq_len(nrow(xTrainRemain)), batchSize)
        p<- stepCost(data.frame(xTrainRemain[batchIndex, ]), y[batchIndex], u, lambda)
        u <- u - (stepSize*p) - lambda*u
        #print(p)
        if((step)%%30==0)
        {
          prediction<-predict(xValidation, u)
          if(index==1)
          {
            accPloty1[graphIndex]<-sum(prediction==yValidation)*100/length(prediction)
            magnitudePloty1[graphIndex]<-norm(as.matrix(u),"f") 
          }
          else if(index==2)
          {
            accPloty2[graphIndex]<-sum(prediction==yValidation)*100/length(prediction)
            magnitudePloty2[graphIndex]<-norm(as.matrix(u),"f") 
          }
          else if(index==3)
          {
            accPloty3[graphIndex]<-sum(prediction==yValidation)*100/length(prediction)
            magnitudePloty3[graphIndex]<-norm(as.matrix(u),"f") 
          }
          else{
            accPloty4[graphIndex]<-sum(prediction==yValidation)*100/length(prediction)
            magnitudePloty4[graphIndex]<-norm(as.matrix(u),"f") 
          }
         
          
          #ploty[graphIndex]<-(cost(data.frame(xHeldOut), yHeldOut, u, lambda))
          #print(ploty[graphIndex])
          
          #plotx[graphIndex]<- graphIndex*30
          graphIndex<-graphIndex+1
          
        }
      }
      if(index==1)
      {
        u1<-u
      }
      else if(index==2)
      {
        u2<-u
      }
      else if(index==3)
      {
        u3<-u
      }
      else
      {
        u4<-u
      }
      
    }
    
    
    #screen(2)
    #lines(plotx, magnitudePloty, type="o", col=color[colorIndex])
    prediction<-predict(xValidation, u)
    accuracies[index]<-sum(prediction==yValidation)/length(prediction)
    print( accuracies[index])
    
    
  }
  
  plotx <- as.matrix(c(1: nrow(accPloty1)), ncol = 1)
  #plotx<-1
  plotx<-plotx*30
  
  plot(plotx, accPloty1, type="o", main=paste("Accuracies lambda= ",lambdas[1]),  xlab ="Iterations", ylab="Accuracy %" )  
  plot(plotx, accPloty2, type="o", main=paste("Accuracies lambda= ",lambdas[2]),  xlab ="Iterations", ylab="Accuracy %" )  
  plot(plotx, accPloty3, type="o", main=paste("Accuracies lambda= ",lambdas[3]),  xlab ="Iterations", ylab="Accuracy %" )  
  plot(plotx, accPloty4, type="o", main=paste("Accuracies lambda= ",lambdas[4]),  xlab ="Iterations", ylab="Accuracy %" )  
  
  plot(plotx, magnitudePloty1, type="o", main=paste("magnitude of the coefficient vector, lambda= ",lambdas[1]),  xlab ="Iterations", ylab="Magnitude" )  
  plot(plotx, magnitudePloty2, type="o", main=paste("magnitude of the coefficient vector, lambda= ",lambdas[2]),  xlab ="Iterations", ylab="Magnitude" )  
  plot(plotx, magnitudePloty3, type="o", main=paste("magnitude of the coefficient vector, lambda= ",lambdas[3]),  xlab ="Iterations", ylab="Magnitude" )  
  plot(plotx, magnitudePloty4, type="o", main=paste("magnitude of the coefficient vector, lambda= ",lambdas[4]),  xlab ="Iterations", ylab="Magnitude" )  
  
  ##selecte 0.01 lambda
 print(paste("lambda= ", lambdas[2]))
      prediction<-predict(xTest, u2)
      print(paste("accuracy= ", sum(prediction==yTest)/length(prediction)))
 
  
}